@extends('layouts.little')

@section('title')
Concours | TELEEDUTOGO
@endsection

@section('h1')
Concours
@endsection

@section('page_description')
Voici quelques épreuves de certains concours pour t'entrainer.
@endsection

@section('content')
<section id="nationaux" class="conteneur-cartes">
    <div class="titre-decrit-plusImage">
        <h2 class="acceuil">Concours nationaux</h2>
        <span class="description">Les consours qui ont lieux sur le téritoire togolais</span>
        <img src="" alt="" class="only-pc">
    </div>
    <div class="list_concours">
        <div class="item">
            <a href="">
                <img src="" alt="">
                <h3 class="acceuil">Titre concousr</h3>
            </a>
            <span class="description">Description du concours</span>
        </div>
        <div class="item">
            <a href="">
                <img src="" alt="">
                <h3 class="acceuil">Concours d'entrée au CIC</h3>
            </a>
            <span class="description">Le CIC est une école d'informatique à l'UL. <a href="https://cic.univ-lome.tg:8084/">Plus d'info sur le CIC</a></span>
        </div>
    </div>
</section>
@endsection

@section('style')
<link rel="stylesheet" type="text/css" href="{{asset('css/concours_exam.css')}}">
@endsection

@section('script')
@endsection
