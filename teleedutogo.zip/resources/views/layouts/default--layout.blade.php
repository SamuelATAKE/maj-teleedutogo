@extends('layouts.default')

@section('title')
@endsection

@section('content')
@endsection

@section('style')
@endsection

@section('script')
@endsection
