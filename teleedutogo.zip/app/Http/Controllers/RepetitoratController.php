<?php

namespace App\Http\Controllers;

use App\Models\Repetitorat;
use Illuminate\Http\Request;

class RepetitoratController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Repetitorat  $repetitorat
     * @return \Illuminate\Http\Response
     */
    public function show(Repetitorat $repetitorat)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Repetitorat  $repetitorat
     * @return \Illuminate\Http\Response
     */
    public function edit(Repetitorat $repetitorat)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Repetitorat  $repetitorat
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Repetitorat $repetitorat)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Repetitorat  $repetitorat
     * @return \Illuminate\Http\Response
     */
    public function destroy(Repetitorat $repetitorat)
    {
        //
    }
}
