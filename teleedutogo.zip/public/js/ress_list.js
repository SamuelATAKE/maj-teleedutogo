let ress_table = document.querySelector('#ress_list_container table');

let dataTable = new simpleDatatables.DataTable(ress_table);