

<?php $__env->startSection('title'); ?>
Concours | TELEEDUTOGO
<?php $__env->stopSection(); ?>

<?php $__env->startSection('h1'); ?>
Concours
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_description'); ?>
Voici quelques épreuves de certains concours pour t'entrainer.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="nationaux" class="conteneur-cartes">
    <div class="titre-decrit-plusImage">
        <h2 class="acceuil">Concours nationaux</h2>
        <span class="description">Les consours qui ont lieux sur le téritoire togolais</span>
        <img src="" alt="" class="only-pc">
    </div>
    <div class="list_concours">
        <div class="item">
            <a href="">
                <img src="" alt="">
                <h3 class="acceuil">Titre concousr</h3>
            </a>
            <span class="description">Description du concours</span>
        </div>
        <div class="item">
            <a href="">
                <img src="" alt="">
                <h3 class="acceuil">Concours d'entrée au CIC</h3>
            </a>
            <span class="description">Le CIC est une école d'informatique à l'UL. <a href="https://cic.univ-lome.tg:8084/">Plus d'info sur le CIC</a></span>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/concours_exam.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.little', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Sam\Projects\teleedutogo\resources\views/parcourir/concours.blade.php ENDPATH**/ ?>