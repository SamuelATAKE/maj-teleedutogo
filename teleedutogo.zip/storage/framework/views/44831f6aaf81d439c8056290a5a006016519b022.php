<?php $__env->startSection('title'); ?>
Connexion
<?php $__env->stopSection(); ?>

<?php $__env->startSection('h1'); ?>
    TELEEDUTOGO : Connexion
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_description'); ?>
    Time to work!<br>
    Connectez-vous.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="conteneur-formulaire1">
    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <div class="case_input">
            <label for="email">Email</label>
            <input type="email" name="email" id="email" placeholder="Votre adresse email" required="">
        </div>
        <div class="case_input">
            <label for="password">Mot de passe</label>
            <input type="password" name="password" id="password" placeholder="Votre mot de passe" required="">
        </div>
        <div class="case_input">
            <label >
                <input type="checkbox" name="seSouvenir" id="se_souvenir">
                Se souvenir de moi
            </label>
        </div>
        <button id="bouton_submit" type="submit" class="actif">
            Se connecter
        </button>
        <div class="other_auth_actions">
            <a href="<?php echo e(route('check.password')); ?>">J'ai oublié mon mot de passe</a>
            <a href="<?php echo e(route('inscription')); ?>">Je n'ai pas encore de compte</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="css/formulaires.css">
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.little', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Sam\Projects\teleedutogo\resources\views/auth/login.blade.php ENDPATH**/ ?>