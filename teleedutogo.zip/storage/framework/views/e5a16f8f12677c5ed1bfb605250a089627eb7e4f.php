<?php $__env->startSection('title'); ?>
Collège | TELEEDUTOGO
<?php $__env->stopSection(); ?>

<?php $__env->startSection('h1'); ?>
Parcourir le collège
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_description'); ?>
Retouvez des cours et des exercices pour le collège
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section id="conteneur_principal" class="espace_college">
		<div class="flex_column">
			<p class="description">Choisissez la classe</p>
			<div class="flex_row_wrap">
				<div class="groupe_classe">
					<a href="<?php echo e(route('classe', ['college','Sixième'])); ?>" class="lien_cont_classe">
						<h2 class="classe">Sixième</h2>
						<hr>
						<p class="description"></p>
					</a>
				</div>
				<div class="groupe_classe">
					<a href="<?php echo e(route('classe', ['college','Cinquième'])); ?>" class="lien_cont_classe">
						<h2 class="classe">Cinquième</h2>
						<hr>
						<p class="description"></p>
					</a>
				</div>
				<div class="groupe_classe">
					<a href="<?php echo e(route('classe', ['college','Quatrième'])); ?>" class="lien_cont_classe">
						<h2 class="classe">Quatrième</h2>
						<hr>
						<p class="description"></p>
					</a>
				</div>
				<div class="groupe_classe">
					<a href="<?php echo e(route('classe', ['college','Troisième'])); ?>" class="lien_cont_classe">
						<h2 class="classe">Troisième</h2>
						<hr>
						<p class="description"></p>
					</a>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/parcourir_css.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.little', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Sam\Projects\teleedutogo\resources\views/parcourir/college.blade.php ENDPATH**/ ?>