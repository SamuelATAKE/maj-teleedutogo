<?php $__env->startSection('title'); ?>
Compléter mes informations | TELEEDUTOGO
<?php $__env->stopSection(); ?>

<?php $__env->startSection('h1'); ?>
TELEEDUTOGO : Complétion des informations
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_description'); ?>
Complètez vos informations pour profiter au maximum des offres du site.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<script>
    let classes_lycee = [
        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($classe->cycle_id == 3): ?>
                "<?php echo e($classe->nom); ?>",
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ];
    let classes_college = [
        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($classe->cycle_id == 2): ?>
                "<?php echo e($classe->nom); ?>",
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ];
    let classes_primaire = [
        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($classe->cycle_id == 1): ?>
                "<?php echo e($classe->nom); ?>",
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ];
    console.log(classes_primaire[0]);
    let matieres_primaire = [
        <?php $__currentLoopData = $matieres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matiere): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($matiere->cycle_id == 1): ?>
                "<?php echo e($matiere->nom); ?> <?php echo e($matiere->classe_id); ?>",
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ]
    let matieres_college = [
        <?php $__currentLoopData = $matieres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matiere): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($matiere->cycle_id == 2): ?>
                "<?php echo e($matiere->nom); ?> <?php echo e($matiere->classe_id); ?>",
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ]
    let matieres_lycee = [
        <?php $__currentLoopData = $matieres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matiere): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($matiere->cycle_id == 3): ?>
                "<?php echo e($matiere->nom); ?> <?php echo e($matiere->classe_id); ?>",
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ]
</script>

<div class="conteneur-formulaire1">
    <form method="POST" action="<?php echo e(route('user.info')); ?>" class="H_multipart_form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <!-- Le role -->
        <div id="part_role" class="form_section" >
            <p class="form_section_num">1</p>
            <div class="case_input">
                <label for='statut'>Statut</label>
                <select name="role" id="statut" value="">
                    <option value="eleve" >Elève</option>
                    <option value="enseignant" >Enseignant</option>
                    <option value="parent" >Parent</option>
                </select>
            </div>
            <div class="boutons_container">
                <p class="bout_suivant">Suivant</p>
            </div>
        </div>
        <!-- Cycle -->
        <div id="part_cycle" class="form_section" >
            <p class="form_section_num">2</p>
            <div class="case_input">
                <label for='cycle'>Cycle</label>
                <select name="cycle" id="cycle" value="">
                    <?php $__currentLoopData = $cycles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cycle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <option value="<?php echo e($cycle->id); ?>" ><?php echo e($cycle->nom_cycle); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="boutons_container">
                <p class="bout_precedent">Précédent</p>
                <p class="bout_suivant">Suivant</p>
            </div>
        </div>
        <!-- Classes -->
        <div id="part_classes" class="form_section" >
            <p class="form_section_num">3</p>
            <div class="case_input">
                <label for='classe1'>Classe enseignée 1</label>
                <select name="classe_id" id="classe1" value="">
                    <option value="cp1" >CP1</option>

                </select>
            </div>
            <div class="case_input classe_enseignant">
                <label for='classe2'>Classe enseignée 2</label>
                <select name="classe_id" id="classe2" value="">
                    <option value="cp1" >CP1</option>

                </select>
            </div>
            <div class="case_input classe_enseignant">
                <label for='classe3'>Classe enseignée 3</label>
                <select name="classe_id" id="classe3" value="">
                    <option value="cp1" >CP1</option>

                </select>
            </div>
            <div class="case_input classe_enseignant">
                <label for='classe4'>Classe enseignée 4</label>
                <select name="classe4" id="classe4" value="">
                    <option value="cp1" >CP1</option>

                </select>
            </div>
            <div class="boutons_container">
                <p class="bout_precedent">Précédent</p>
                <p class="bout_suivant">Suivant</p>
            </div>
        </div>
        <!-- Matières -->
        <div id="part_matiere" class="form_section" >
            <p class="form_section_num">4</p>
            <div class="case_input">
                <label for='matiere1'>Matière enseignée 1</label>
                <!-- Les matières seront remplis uniquement par les enseigants du collège ou lycée -->
                <select name="matiere1" id="matiere1" value="">
                    <option value="math">math</option>

                </select>
            </div>
            <div class="case_input">
                <label for='matiere2'>Matière enseignée 2</label>
                <select name="matiere2" id="matiere2" value="">
                    <option value="math" >math</option>

                </select>
            </div>
            <div class="case_input">
                <label for='matiere3'>Matière enseignée 3</label>
                <select name="matiere3" id="matiere3" value="">
                    <option value="math" >math</option>

                </select>
            </div>
            <div class="boutons_container">
                <p class="bout_precedent">Précédent</p>
                <p class="bout_suivant">Suivant</p>
            </div>
        </div>
        <!-- Etablissement scolaire -->
        <div id="part_etablissement" class="form_section" >
            <p class="form_section_num">5</p>
            <div class="case_input">
                <label for='etablissement'>Etablissement Scolaire [Facultatif]</label>
                <input type="text" id="etablissement" name="etablissement" placeholder="Entrez le nom de votre établissement scolaire.">
            </div>
            <div class="boutons_container">
                <p class="bout_precedent">Précédent</p>
                <p class="bout_suivant">Suivant</p>
            </div>
        </div>
        <!-- Regions -->
        <div id="part_region" class="form_section" >
            <p class="form_section_num">6</p>
            <div class="case_input">
                <label for='region'>Région [Facultatif]</label>
                <select name="region" id="region">
                    <option value="lome">Lomé</option>
                    <option value="maritime">Maritime</option>
                    <option value="plateaux">Plateaux</option>
                    <option value="centrale">Centrale</option>
                    <option value="kara">Kara</option>
                    <option value="savanes">Savanes</option>
                </select>
            </div>
            <div class="boutons_container">
                <p class="bout_precedent">Précédent</p>
                <button type="submit" class="bout_soumettre">Soumettre</button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/formulaires.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/compl_infos.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/compl_infos.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.little', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Sam\Projects\teleedutogo\resources\views/forms/completer_info.blade.php ENDPATH**/ ?>