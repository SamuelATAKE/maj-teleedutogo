<?php $__env->startSection('title'); ?>
Ajouter une classe
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('css/ress_list.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_title'); ?>
Classe
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section id="ress_list_container">
    <h1>Liste des classes</h1>
    <div class="ress_table_container">
        <a href="<?php echo e(route('classe.create')); ?>"><button class="btn btn-primary">Ajouter classe</button></a>
        <table class="ress_table">
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Cycle</th>
                    <th>Serie</th>
                    <th>Gestion</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($classe->nom); ?></td>
                        <td><?php echo e($classe->cycle->nom_cycle); ?></td>
                        <td><?php if($classe->serie): ?> <?php echo e($classe->serie->nom); ?><?php else: ?> <?php endif; ?></td>
                        <td class='actions_cel'>
                                <a href="<?php echo e(route("classe.edit", $classe->id)); ?>">
                                    <button type='button' title="Modifier">
                                        <img src="<?php echo e(asset('images/edit_icon.png')); ?>" alt="">
                                    </button>
                                </a>
                            <form action="" class="del_button_form">
                                <input type="hidden">
                                <button type='submit' title="Supprimer">
                                    <img src="<?php echo e(asset('images/del_icon.png')); ?>" alt="">
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td>Pas de classes</td></tr>
                <?php endif; ?>

            </tbody>
        </table>
    </div>

</section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('head_script'); ?>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/ress_list.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Sam\Projects\teleedutogo\resources\views/admin/classes/index.blade.php ENDPATH**/ ?>