


<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/404.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
Erreur 404
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="main-container">
    <h1>Erreur 404</h1>
    <div class="img-container">
        <picture>
            <img src="<?php echo e(asset('images/404.png')); ?>" alt="404">
        </picture>
    </div>
    <p class="info">
        La page que vous demandez n'existe pas.
    </p>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Sam\Projects\teleedutogo\resources\views/errors/404.blade.php ENDPATH**/ ?>