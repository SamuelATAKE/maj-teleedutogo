<?php $__env->startSection('title'); ?>
Ajout de série
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/formulaires.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_title'); ?>
Séries > Ajouter
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="conteneur-formulaire1">
    <form method="POST" action="<?php echo e(route('serie.add')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <div class="case_input input_chapitre">
            <label for="chapitre">Série</label>
            <input type="text" id="chapitre" name="serie" placeholder="Série">
        </div>
        <button id="bouton_submit" type="submit" class="actif">
            Ajouter
        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/contribution.js')); ?>"></script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Sam\Projects\teleedutogo\resources\views/grades/ajouter_serie.blade.php ENDPATH**/ ?>