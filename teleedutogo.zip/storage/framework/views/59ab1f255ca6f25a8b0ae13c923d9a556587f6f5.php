<?php $__env->startSection('title'); ?>
Inscription
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/formulaires.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('h1'); ?>
    TELEEDUTOGO : Inscription
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_description'); ?>
Inscrivez-vous.<br>Rejoignez la communauté.
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="conteneur-formulaire1">
    <form method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <div class="case_input">
            <label for="nom">Nom</label>
            <input type="text" name="nom" id="nom" placeholder="Entrez votre nom ici" required="">
        </div>
        <div class="case_input">
            <label for="prenom">Prénom(s)</label>
            <input type="text" name="prenom" id="prenom" placeholder="Entrez votre prénom ici" required="">
        </div>
        <div class="case_input">
            <label for="email">Email</label>
            <input type="email" name="email" id="email" placeholder="Votre adresse email" required="">
        </div>
        <div class="case_input">
            <label for="password">Mot de passe pour votre compte</label>
            <input type="password" name="password" id="password" placeholder="Six (6) caractères au minimum" required="">
        </div>
        <div class="case_input">
            <label for="confirm_pass">Confimation du mot de passe</label>
            <input type="password" name="confirm_pass" id="confirm_pass" placeholder="Confirmez votre mot de passe" required="">
        </div>
        <div class="case_input">
            <label >
                <input type="checkbox" name="seSouvenir" id="se_souvenir">
                Se souvenir de moi
            </label>
        </div>

        <p class="indication">
            Veuillez renseigner tous les champs avec des informations correctes, s'il vous plaît
        </p>
        <button id="bouton_submit" type="submit" class="non-actif">
            S'inscrire
        </button>
    </form>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/inscription.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.little', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Sam\Projects\teleedutogo\resources\views/auth/register.blade.php ENDPATH**/ ?>