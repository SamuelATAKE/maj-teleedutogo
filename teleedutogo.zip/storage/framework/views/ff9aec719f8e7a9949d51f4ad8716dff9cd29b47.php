<?php $__env->startSection('title'); ?>
Ajout de matière
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/formulaires.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_title'); ?>
Matieres > Ajouter
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="conteneur-formulaire1">
    <form method="POST" action="<?php echo e(route('matiere.add')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>

        <div class="case_input input_chapitre">
            <label for="chapitre">Nom</label>
            <input type="text" id="chapitre" name="nom" placeholder="Intitulé de la matière">
        </div>
        <div class="case_input">
            <label for="type">Classe</label>
            <select name="classe" id="type" required="">
                <option value="" selected></option>
                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($classe->id); ?>"><?php echo e($classe->nom); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>
        </div>
        <button id="bouton_submit" type="submit" class="actif">
            Ajouter
        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/contribution.js')); ?>"></script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Sam\Projects\teleedutogo\resources\views/grades/ajouter_matiere.blade.php ENDPATH**/ ?>