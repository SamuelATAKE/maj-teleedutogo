<?php $__env->startSection('title'); ?>
    Editer une Classe
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/formulaires.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_title'); ?>
    Classes > Editer
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="conteneur-formulaire1">
        <form method="POST" action="<?php echo e(route('classe.update', $classe->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <div class="case_input input_chapitre">
                <label for="chapitre">Nom</label>
                <input type="text" id="chapitre" name="nom" placeholder="<?php echo e($classe->nom); ?>" value="<?php echo e($classe->nom); ?>">
            </div>
            <div class="case_input">
                <label for="type">Cycle</label>
                <select name="cycle" id="type" required="">
                    <option value="<?php echo e($classe->cycle->id); ?>" selected><?php echo e($classe->cycle->nom); ?></option>
                    <?php $__currentLoopData = $cycles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cycle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cycle->id); ?>"><?php echo e($cycle->nom_cycle); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>
            <div class="case_input">
                <label for="examen">Série</label>
                <select name="serie" id="examen">
                    <?php if($classe->serie): ?>
                        <option value="<?php echo e($classe->serie->id); ?>"><?php echo e($classe->serie->nom); ?></option>
                    <?php else: ?>
                        <option value="" selected></option>
                    <?php endif; ?>

                    <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($serie->id); ?>"><?php echo e($serie->nom_serie); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="case_input">
                <label for="description">Description[facultative]</label>
                <textarea name="description" id="description" rows="10" placeholder="Vous pouvez en dire plus sur la classe ici"></textarea>
            </div>
            <button id="bouton_submit" type="submit" class="actif">
                Mettre à jour
            </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/contribution.js')); ?>"></script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Sam\Projects\teleedutogo\resources\views/admin/classes/edit.blade.php ENDPATH**/ ?>