<?php $__env->startSection('title'); ?>
Ajout de ressource
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/formulaires.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_title'); ?>
Ressources > Ajouter
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="conteneur-formulaire1">
    <form method="POST" action="<?php echo e(route('ressource.add')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <div class="case_input">
            <label for="files">Ressource</label>
            <input type="file" name="ressource" multiple>
        </div>
        <div class="case_input">
            <label for="cycle">Cycle</label>
            <select name="cycle" id="cycle">
                <?php $__currentLoopData = $cycles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cycle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($cycle->id); ?>"><?php echo e($cycle->nom_cycle); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="case_input">
            <label for='classe'>Classe</label>
            <select name="classe" id="classe">
                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($classe->id); ?>"><?php echo e($classe->nom); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>
        </div>
        <div class="case_input">
            <label for="matiere">Matière</label>
            <select name="matiere" id="matiere" required="">
                <option value="" selected></option>
                <optgroup label="Lycée">
                    <?php $__currentLoopData = $matieres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matiere): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($matiere->cycle_id == 3): ?>
                          <option value="<?php echo e($matiere->id); ?>"><?php echo e($matiere->nom); ?> (<?php echo e($nom_classe[$matiere->id]); ?>)</option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </optgroup>
                <optgroup label="Collège">
                    <?php $__currentLoopData = $matieres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matiere): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($matiere->cycle_id == 2): ?>
                            <option value="<?php echo e($matiere->id); ?>"><?php echo e($matiere->nom); ?>  (<?php echo e($nom_classe[$matiere->id]); ?>)</option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </optgroup>
                <optgroup label="Primaire">
                    <?php $__currentLoopData = $matieres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matiere): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($matiere->cycle_id == 1): ?>
                            <option value="<?php echo e($matiere->id); ?>"><?php echo e($matiere->nom); ?>  (<?php echo e($nom_classe[$matiere->id]); ?>)</option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </optgroup>
            </select>
        </div>
        <div class="case_input">
            <label for="type">Type de la ressource</label>
            <select name="type" id="type" required="">
                <option value="" selected></option>
                <option value="cours">Cours ou résumé de cours</option>
                <option value="examen">Examen Nationnal(CEPD,BEPC...)</option>
                <option value="epreuve">Epreuve d'une école</option>
                <option value="concours">Epreuve d'un concours</option>
                <option value="exercice">Exercice</option>
            </select>
        </div>
        <div class="case_input input_examen">
            <label for="examen">Examen</label>
            <select name="examen" id="examen">
                <option value="CEPD">CEPD</option>
                <option value="BEPC">BEPC</option>
                <option value="PROBA">PROBATOIRE</option>
                <option value="BAC">BAC</option>
            </select>
        </div>
        <div class="case_input input_etablissemenent">
            <label for="etablissement">Etablissement Scolaire</label>
            <input type="text" id="etablissement" name="etablissement" placeholder="L'école de la ressource">
        </div>
        <div class="case_input input_annee">
            <label for="annee">Année</label>
            <input type="number" id="annee" name="annee" min="1900">
        </div>
        <div class="case_input input_chapitre">
            <label for="chapitre">Chapitre</label>
            <input type="text" id="chapitre" name="chapitre" placeholder="Chapitre">
        </div>
        <div class="case_input">
            <label for="description">Description[facultative]</label>
            <textarea name="description" id="description" rows="10" placeholder="Vous pouvez en dire plus sur la ressource ici."></textarea>
        </div>
        <button id="bouton_submit" type="submit" class="actif">
            Ajouter
        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/contribution.js')); ?>"></script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Sam\Projects\teleedutogo\resources\views/admin/ajout_ressource.blade.php ENDPATH**/ ?>