

<?php $__env->startSection('title'); ?>
>classe< | TELEEDUTOGO
<?php $__env->stopSection(); ?>

<?php $__env->startSection('h1'); ?>
<?php echo e($classe->nom); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_description'); ?>
N'arrêtez jamais d'apprendre!
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="general_container">
		<section class="flex_row_wrap conteneur_matieres">
            <?php $__currentLoopData = $matieres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matiere): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <section class="bloc_matiere">
                    <h2><?php echo e($matiere->nom); ?></h2>
                    <p class="niveau">
                        <span class="classe"><?php echo e($classe->nom); ?></span>
                        
                    </p>
                    <div class="contenu_matiere">
                        <!-- Partie cours -->
                        <p class="cours">
                            <img src="<?php echo e(asset('images/icon_pour_cours.png')); ?>" alt="">
                            <a href="<?php echo e(route('matiere', [$cycle, $classe->nom, $matiere->nom])); ?>">Aller aux cours</a>
                        </p>
                        <hr>
                        <!-- Partie exercices -->
                        <p class="exercice">
                            <img src="<?php echo e(asset('images/icon_pour_exercice.png')); ?>" alt="">
                            <a href="">Aller aux exercices</a>
                        </p>
                    </div>
                    <p class="contribuer">
                        <a href="">Vous avez des ressources? Contribuez</a>
                    </p>
                </section>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			
		</section>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/affich_matiere.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/affich_classe.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.little', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Sam\Projects\teleedutogo\resources\views/parcourir/template_classe.blade.php ENDPATH**/ ?>